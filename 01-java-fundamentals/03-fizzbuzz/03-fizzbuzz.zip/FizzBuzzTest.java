public class FizzBuzzTest {

    public static void main(String[] args) {
        FizzBuzz fb = new FizzBuzz();
        fb.counter();
    }
    
 
}
