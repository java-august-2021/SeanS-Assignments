function dateAlert() {
	alert('The date page has been loaded');
}
	
function timeAlert() {
	alert('The time page has been loaded');
}